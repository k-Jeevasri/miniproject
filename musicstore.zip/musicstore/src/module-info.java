/**
 * 
 */
/**
 * 
 */
module musicstore {
}