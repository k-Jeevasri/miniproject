package musicstore;
import java.util.Scanner;
public class Main {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        InstrumentDAO instrumentDAO = new InstrumentDAO();
	        CustomerDAO customerDAO = new CustomerDAO();
	        SaleDAO saleDAO = new SaleDAO();
	        while (true) {
	            System.out.println("\nMusic Store Menu:");
	            System.out.println("1. Add Instrument");
	            System.out.println("2. Search Instrument");
	            System.out.println("3. Update Instrument Price");
	            System.out.println("4. Delete Instrument");
	            System.out.println("5. Add Customer");
	            System.out.println("6. Record Sale");
	            System.out.println("7. Exit");
	            System.out.print("Enter your choice (1-7): ");
	            int choice = InputUtils.getIntInput(scanner);
	            switch (choice) {
	                case 1:
	                    System.out.print("Enter instrument name: ");
	                    String instrumentName = scanner.nextLine();
	                    System.out.print("Enter instrument price: ");
	                    double instrumentPrice = InputUtils.getDoubleInput(scanner);
	                    Instrument instrument = new Instrument(instrumentName, instrumentPrice);
	                    instrumentDAO.addInstrument(instrument);
	                    break;
	                case 2:
	                    System.out.print("Enter instrument name to search: ");
	                    String searchName = scanner.nextLine();
	                    Instrument searchedInstrument = instrumentDAO.searchInstrument(searchName);
	                    if (searchedInstrument != null) {
	                        System.out.println("Instrument found:");
	                        System.out.println(searchedInstrument);
	                    } else {
	                        System.out.println("Instrument not found.");
	                    }
	                    break;
	                case 3:
	                    System.out.print("Enter instrument name to update price: ");
	                    String updateName = scanner.nextLine();
	                    System.out.print("Enter new price: ");
	                    double newPrice = InputUtils.getDoubleInput(scanner);
	                    boolean updated = instrumentDAO.updateInstrumentPrice(updateName, newPrice);
	                    if (updated) {
	                        System.out.println("Instrument price updated successfully.");
	                    } else {
	                        System.out.println("Failed to update instrument price.");
	                    }
	                    break;
	                case 4:
	                    System.out.print("Enter instrument name to delete: ");
	                    String deleteName = scanner.nextLine();
	                    boolean deleted = instrumentDAO.deleteInstrument(deleteName);
	                    if (deleted) {
	                        System.out.println("Instrument deleted successfully.");
	                    } else {
	                        System.out.println("Failed to delete instrument.");
	                    }
	                    break;
	                case 5:
	                    System.out.print("Enter customer name: ");
	                    String customerName = scanner.nextLine();
	                    Customer customer = new Customer(customerName);
	                    customerDAO.addCustomer(customer);
	                    break;
	                case 6:
	                    System.out.print("Enter customer name: ");
	                    String saleCustomerName = scanner.nextLine();
	                    System.out.print("Enter instrument name: ");
	                    String saleInstrumentName = scanner.nextLine();
	                    System.out.print("Enter quantity sold: ");
	                    int quantitySold = InputUtils.getIntInput(scanner);
	                    Sale sale = new Sale(saleCustomerName, saleInstrumentName, quantitySold);
	                    saleDAO.recordSale(sale);
	                    break;
	                case 7:
	                    System.out.println("Exiting program...");
	                    scanner.close();
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	                    break;
	            }
	        }
	    }
	}


}
