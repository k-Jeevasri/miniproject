package musicstore;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	public class InstrumentDAO {
	    public void addInstrument(Instrument instrument) {
	        try (Connection conn = DatabaseConnector.getConnection()) {
	            String insertSql = "INSERT INTO music_store (id, name, price) " +
	                    "VALUES (music_store_seq.nextval, ?, ?)";
	            PreparedStatement pstmt = conn.prepareStatement(insertSql);
	            pstmt.setString(1, instrument.getName());
	            pstmt.setDouble(2, instrument.getPrice());
	            int rowsInserted = pstmt.executeUpdate();
	            if (rowsInserted > 0) {
	                System.out.println("Instrument added successfully.");
	            } else {
	                System.out.println("Failed to add instrument.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    public Instrument searchInstrument(String name) {
	        try (Connection conn = DatabaseConnector.getConnection()) {
	            String selectSql = "SELECT * FROM music_store WHERE name = ?";
	            PreparedStatement pstmt = conn.prepareStatement(selectSql);
	            pstmt.setString(1, name);
	            ResultSet rs = pstmt.executeQuery();
	            if (rs.next()) {
	                int id = rs.getInt("id");
	                double price = rs.getDouble("price");
	                return new Instrument(id, name, price);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    public boolean updateInstrumentPrice(String name, double newPrice) {
	        try (Connection conn = DatabaseConnector.getConnection()) {
	            String updateSql = "UPDATE music_store SET price = ? WHERE name = ?";
	            PreparedStatement pstmt = conn.prepareStatement(updateSql);
	            pstmt.setDouble(1, newPrice);
	            pstmt.setString(2, name);
	            int rowsUpdated = pstmt.executeUpdate();
	            return rowsUpdated > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	    }
	    public boolean deleteInstrument(String name) {
	        try (Connection conn = DatabaseConnector.getConnection()) {
	            String deleteSql = "DELETE FROM music_store WHERE name = ?";
	            PreparedStatement pstmt = conn.prepareStatement(deleteSql);
	            pstmt.setString(1, name);
	            int rowsDeleted = pstmt.executeUpdate();
	            return rowsDeleted > 0;
	        } catch (SQLException e) {
	            e.printStackTrace(); }return false;
	    }
	}

