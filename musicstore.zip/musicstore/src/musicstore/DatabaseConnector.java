package musicstore;
import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnector {
	Connection con=null;
        try {
        	String DB_URL = "jdbc:oracle:thin:@localhost:1521:XE";
        	   String DB_USERNAME = "system";
        	    String DB_PASSWORD = "123";
			con= DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
        return con;
    }
}
