package musicstore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SaleDAO {
    public void recordSale(Sale sale) {
        try (Connection conn = DatabaseConnector.getConnection()) {
            String selectCustomerSql = "SELECT id FROM customers WHERE name = ?";
            PreparedStatement customerStmt = conn.prepareStatement(selectCustomerSql);
            customerStmt.setString(1, sale.getCustomerName());
            ResultSet customerRs = customerStmt.executeQuery();
            int customerId;
            if (customerRs.next()) {
                customerId = customerRs.getInt("id");
            } else {
                System.out.println("Customer not found.");
                return;
            }
            customerRs.close();
            customerStmt.close();
            String selectInstrumentSql = "SELECT id, price FROM music_store WHERE name = ?";
            PreparedStatement instrumentStmt = conn.prepareStatement(selectInstrumentSql);
            instrumentStmt.setString(1, sale.getInstrumentName());
            ResultSet instrumentRs = instrumentStmt.executeQuery();
            int instrumentId;
            double instrumentPrice;
            if (instrumentRs.next()) {
                instrumentId = instrumentRs.getInt("id");
                instrumentPrice = instrumentRs.getDouble("price");
            } else {
                System.out.println("Instrument not found.");
                return;
            }
            instrumentRs.close();
            instrumentStmt.close();
            double totalPrice = instrumentPrice * sale.getQuantitySold();
            String insertSaleSql = "INSERT INTO sales (id, customer_id, instrument_id, quantity, total_price, sale_date) " +
                    "VALUES (sales_seq.nextval, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
            PreparedStatement pstmt = conn.prepareStatement(insertSaleSql);
            pstmt.setInt(1, customerId);
            pstmt.setInt(2, instrumentId);
            pstmt.setInt(3, sale.getQuantitySold());
            pstmt.setDouble(4, totalPrice);
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Sale recorded successfully.");
            } else {
                System.out.println("Failed to record sale.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

