package musicstore;
import java.util.InputMismatchException;
import java.util.Scanner;

public class InputUtils {
    public static int getIntInput(Scanner scanner) {
        while (true) {
            try {
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.print("Invalid input. Please enter a valid integer: ");
            }
        }
    }

    public static double getDoubleInput(Scanner scanner) {
        while (true) {
            try {
                return scanner.nextDouble();
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.print("Invalid input. Please enter a valid number: ");
            }
        }
    }
}

