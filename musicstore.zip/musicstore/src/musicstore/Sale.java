package musicstore;

public class Sale {
  private String customerName;
  private String instrumentName;
  private int sold;
  public Sale(String customerName,String instrumentName,int sold)
  {
	  this.customerName=customerName;
	  this.instrumentName=instrumentName;
	  this.sold=sold;
  }
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getInstrumentName() {
	return instrumentName;
}
@Override
public String toString() {
	return "Sale [customerName=" + customerName + ", instrumentName=" + instrumentName + ", sold=" + sold + "]";
}
public void setInstrumentName(String instrumentName) {
	this.instrumentName = instrumentName;
}
public int getSold() {
	return sold;
}
public void setSold(int sold) {
	this.sold = sold;
}
}
